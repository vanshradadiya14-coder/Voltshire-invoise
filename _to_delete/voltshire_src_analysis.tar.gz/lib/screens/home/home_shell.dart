import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../providers/dashboard_v2_provider.dart';
import '../../widgets/quick_add_sheet.dart';

/// The main app scaffold hosting the bottom navigation bar and the current
/// tab's navigator (via [StatefulNavigationShell]).
class HomeShell extends ConsumerWidget {
  const HomeShell({required this.navigationShell, super.key});

  final StatefulNavigationShell navigationShell;

  void _goBranch(int index) {
    navigationShell.goBranch(
      index,
      // Tapping the active tab returns it to its root.
      initialLocation: index == navigationShell.currentIndex,
    );
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    // Badge the Home tab when something needs attention, so a builder who has
    // overdue invoices sees it without opening the app's dashboard first.
    final int alerts = ref.watch(actionCentreProvider).length;

    return Scaffold(
      body: navigationShell,

      // A single create button, always in the same place. Previously every
      // screen had its own FAB and creating anything meant navigating to the
      // right tab first.
      floatingActionButton: FloatingActionButton(
        onPressed: () => showQuickAddSheet(context),
        tooltip: 'Create',
        child: const Icon(Icons.add),
      ),

      bottomNavigationBar: NavigationBar(
        selectedIndex: navigationShell.currentIndex,
        onDestinationSelected: _goBranch,
        destinations: <NavigationDestination>[
          NavigationDestination(
            icon: Badge.count(
              count: alerts,
              isLabelVisible: alerts > 0,
              child: const Icon(Icons.dashboard_outlined),
            ),
            selectedIcon: Badge.count(
              count: alerts,
              isLabelVisible: alerts > 0,
              child: const Icon(Icons.dashboard),
            ),
            label: 'Home',
          ),
          const NavigationDestination(
            icon: Icon(Icons.people_outline),
            selectedIcon: Icon(Icons.people),
            label: 'Customers',
          ),
          const NavigationDestination(
            icon: Icon(Icons.construction_outlined),
            selectedIcon: Icon(Icons.construction),
            label: 'Jobs',
          ),
          const NavigationDestination(
            icon: Icon(Icons.receipt_long_outlined),
            selectedIcon: Icon(Icons.receipt_long),
            label: 'Invoices',
          ),
          const NavigationDestination(
            icon: Icon(Icons.grid_view_outlined),
            selectedIcon: Icon(Icons.grid_view),
            label: 'More',
          ),
        ],
      ),
    );
  }
}
